const express=require("express");
const cookieParser=require("cookie-parser");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const Database=require("better-sqlite3");
const path=require("path");

const app=express();
const db=new Database("nabta.db");
const PORT=process.env.PORT||3000;
const SECRET=process.env.JWT_SECRET||"CHANGE_ME_IN_PRODUCTION";
const ADMIN_USERNAME=process.env.ADMIN_USERNAME||"admin";
const ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||"CHANGE_ME_NOW";

app.use(express.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname,"public")));

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 points INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS settings(
 key TEXT PRIMARY KEY,
 value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS history(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 text TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES('owner_rate','70')").run();

function tokenFor(user){
  return jwt.sign({id:user.id,username:user.username,admin:!!user.admin},SECRET,{expiresIn:"7d"});
}
function auth(req,res,next){
  try{
    const t=req.cookies.nabta_token;
    if(!t) return res.status(401).json({error:"يجب تسجيل الدخول"});
    const p=jwt.verify(t,SECRET);
    const user=db.prepare("SELECT id,username,points FROM users WHERE id=?").get(p.id);
    if(!user) return res.status(401).json({error:"الحساب غير موجود"});
    req.user={...user,admin:!!p.admin}; next();
  }catch(e){return res.status(401).json({error:"جلسة الدخول منتهية"});}
}
function admin(req,res,next){ if(!req.user.admin) return res.status(403).json({error:"صلاحية المشرف مطلوبة"}); next(); }

app.post("/api/register",(req,res)=>{
  const {username,password}=req.body||{};
  if(!username||!password||String(username).length<3||String(password).length<6)
    return res.status(400).json({error:"اسم المستخدم 3 أحرف على الأقل وكلمة المرور 6 أحرف على الأقل"});
  try{
    const hash=bcrypt.hashSync(password,12);
    const info=db.prepare("INSERT INTO users(username,password_hash) VALUES(?,?)").run(username.trim(),hash);
    const user={id:info.lastInsertRowid,username:username.trim(),points:0,admin:false};
    res.cookie("nabta_token",tokenFor(user),{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:7*86400000});
    res.json({user});
  }catch(e){res.status(409).json({error:"اسم المستخدم مستخدم مسبقاً"});}
});

app.post("/api/login",(req,res)=>{
  const {username,password}=req.body||{};
  const row=db.prepare("SELECT id,username,password_hash,points FROM users WHERE username=?").get(String(username||"").trim());
  if(!row||!bcrypt.compareSync(password||"",row.password_hash)) return res.status(401).json({error:"بيانات الدخول غير صحيحة"});
  const isAdmin=row.username===ADMIN_USERNAME && (process.env.ADMIN_PASSWORD||ADMIN_PASSWORD)!=="";
  const user={id:row.id,username:row.username,points:row.points,admin:isAdmin};
  res.cookie("nabta_token",tokenFor(user),{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:7*86400000});
  res.json({user});
});

app.post("/api/logout",(req,res)=>{res.clearCookie("nabta_token");res.json({ok:true});});

app.get("/api/me",auth,(req,res)=>{
  const ownerRate=Number(db.prepare("SELECT value FROM settings WHERE key='owner_rate'").get().value);
  res.json({user:req.user,ownerRate,userRate:100-ownerRate});
});

app.post("/api/tasks/:points",auth,(req,res)=>{
  const n=Math.floor(Number(req.params.points));
  if(![100,250].includes(n)) return res.status(400).json({error:"مهمة غير معروفة"});
  db.prepare("UPDATE users SET points=points+? WHERE id=?").run(n,req.user.id);
  db.prepare("INSERT INTO history(user_id,text) VALUES(?,?)").run(req.user.id,`+${n} نقطة — مهمة`);
  const u=db.prepare("SELECT id,username,points FROM users WHERE id=?").get(req.user.id);
  res.json({user:u});
});

app.post("/api/redeem",auth,(req,res)=>{
  if(req.user.points<500) return res.status(400).json({error:"تحتاج إلى 500 نقطة على الأقل"});
  db.prepare("UPDATE users SET points=points-500 WHERE id=?").run(req.user.id);
  db.prepare("INSERT INTO history(user_id,text) VALUES(?,?)").run(req.user.id,"-500 نقطة — استبدال تجريبي");
  const u=db.prepare("SELECT id,username,points FROM users WHERE id=?").get(req.user.id);
  res.json({user:u});
});

app.get("/api/history",auth,(req,res)=>{
  res.json(db.prepare("SELECT text,created_at FROM history WHERE user_id=? ORDER BY id DESC").all(req.user.id));
});

app.get("/api/admin/summary",auth,admin,(req,res)=>{
  const users=db.prepare("SELECT id,username,points,created_at FROM users ORDER BY id DESC").all();
  const ownerRate=Number(db.prepare("SELECT value FROM settings WHERE key='owner_rate'").get().value);
  const totalPoints=db.prepare("SELECT COALESCE(SUM(points),0) n FROM users").get().n;
  res.json({users,ownerRate,userRate:100-ownerRate,totalUsers:users.length,totalPoints});
});

app.post("/api/admin/profit-rate",auth,admin,(req,res)=>{
  const n=Number(req.body.rate);
  if(!Number.isFinite(n)||n<0||n>100) return res.status(400).json({error:"النسبة يجب أن تكون بين 0 و100"});
  db.prepare("UPDATE settings SET value=? WHERE key='owner_rate'").run(String(n));
  res.json({ownerRate:n,userRate:100-n});
});

app.post("/api/admin/users/:id/points",auth,admin,(req,res)=>{
  const delta=Math.trunc(Number(req.body.delta));
  if(!Number.isFinite(delta)||Math.abs(delta)>1000000) return res.status(400).json({error:"قيمة غير صالحة"});
  db.prepare("UPDATE users SET points=MAX(0,points+?) WHERE id=?").run(delta,req.params.id);
  res.json(db.prepare("SELECT id,username,points FROM users WHERE id=?").get(req.params.id));
});

app.listen(PORT,()=>console.log(`Nabta Rewards server running on port ${PORT}`));
